// Test link thang toi output/libconfig.so (khong include ma nguon runtime).
#include "config_api.h"
#include <cmath>
#include <cstdio>
#include <cstdlib>

static int g_fail = 0;
#define CHECK(cond) do { if (!(cond)) { std::printf("  FAIL: %s (dong %d)\n", #cond, __LINE__); ++g_fail; } \
                         else std::printf("  ok:   %s\n", #cond); } while (0)
static bool near(float a, float b) { return std::fabs(a - b) < 1e-4f; }

int main() {
    const char* path = "/tmp/config_so_test.cfg";
    std::remove(path);
    std::printf("%s\n", config_build_info());

    float v = -1;
    CHECK(config_get_float("sensitivity", &v) != 0);          // chua init -> loi
    CHECK(config_init(path) == 0);

    CHECK(config_get_float("sensitivity", &v) == 0 && near(v, 1.0f));   // mac dinh tu FROM.xml
    CHECK(config_get_float("deadZone", &v) == 0 && near(v, 0.05f));
    CHECK(config_get_float("khong_ton_tai", &v) != 0);

    CHECK(config_set_float("smooth", 0.8f) == 0);
    CHECK(config_get_float("smooth", &v) == 0 && near(v, 0.8f));
    CHECK(config_set_float("maxSpeed", 99999.0f) == 0);                 // bi kep ve max
    CHECK(config_get_float("maxSpeed", &v) == 0 && near(v, 1000.0f));
    CHECK(config_set_float("sensitivity", NAN) != 0);

    CHECK(config_set_float("sensitivity", 2.5f) == 0);
    CHECK(config_save() == 0);
    config_shutdown();

    CHECK(config_init(path) == 0);                                      // nap lai tu file that
    CHECK(config_get_float("sensitivity", &v) == 0 && near(v, 2.5f));
    CHECK(config_get_float("smooth", &v) == 0 && near(v, 0.8f));

    CHECK(config_reset() == 0);
    CHECK(config_get_float("sensitivity", &v) == 0 && near(v, 1.0f));

    // Bo loc: trong dead zone -> 0; ngoai -> tien ve target va khong vuot maxSpeed.
    CHECK(near(config_apply_filter(0.02f, 0.0f, 0.016f), 0.0f));
    float y = 0.0f;
    for (int k = 0; k < 600; ++k) y = config_apply_filter(1.0f, y, 0.016f);
    CHECK(y > 90.0f && y <= 100.0001f);

    config_shutdown();
    std::remove(path);
    std::printf(g_fail ? "\n%d test THAT BAI\n" : "\nTat ca test dat\n", g_fail);
    return g_fail ? 1 : 0;
}
