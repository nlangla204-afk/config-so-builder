/* Module C thuan: chung minh Builder bien dich duoc ca file .c */
#include "config_api.h"

#ifndef CONFIG_BUILD_STAMP
#define CONFIG_BUILD_STAMP "unknown"
#endif

CONFIG_API const char* config_build_info(void) {
    return "config_runtime (C++17) + buildinfo (C) | built " CONFIG_BUILD_STAMP;
}
