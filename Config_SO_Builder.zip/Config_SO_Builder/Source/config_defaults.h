// Bang mac dinh/gioi han cua cac Value. Du lieu do build.sh SINH RA tu FROM.xml
// (build/generated/config_defaults.cpp). Muon doi gia tri: sua FROM.xml, khong sua tay.
#pragma once
#include <stddef.h>

struct ConfigDefault {
    const char* name;
    float def;
    float min;
    float max;
};

extern const ConfigDefault kConfigDefaults[];
extern const size_t        kConfigDefaultCount;
extern const char* const   kConfigName;
extern const char* const   kConfigVersion;
