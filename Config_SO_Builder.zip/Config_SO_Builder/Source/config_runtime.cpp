// Config runtime: kho gia tri float thuc su (thread-safe), nap/ghi file, kep min/max.
#include "config_api.h"
#include "config_defaults.h"

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <mutex>
#include <string>
#include <unordered_map>

namespace {

struct Entry { float value; float def; float min; float max; };

std::mutex                             g_mutex;
std::unordered_map<std::string, Entry> g_values;
std::string                            g_path;
bool                                   g_ready = false;
thread_local std::string               t_error;

int fail(const std::string& msg) { t_error = msg; return -1; }

std::string trim(const std::string& s) {
    size_t a = 0, b = s.size();
    while (a < b && std::isspace(static_cast<unsigned char>(s[a]))) ++a;
    while (b > a && std::isspace(static_cast<unsigned char>(s[b - 1]))) --b;
    return s.substr(a, b - a);
}

void load_defaults() {
    g_values.clear();
    for (size_t i = 0; i < kConfigDefaultCount; ++i) {
        const ConfigDefault& d = kConfigDefaults[i];
        g_values[d.name] = Entry{d.def, d.def, d.min, d.max};
    }
}

// Doc file key=value. Dong '#' la comment. Key la hoac gia tri sai -> bo qua.
void load_file(const std::string& path) {
    FILE* f = std::fopen(path.c_str(), "r");
    if (!f) return;                         // chua co file: khong phai loi
    char line[256];
    while (std::fgets(line, sizeof line, f)) {
        std::string s = trim(line);
        if (s.empty() || s[0] == '#') continue;
        size_t eq = s.find('=');
        if (eq == std::string::npos) continue;
        std::string key = trim(s.substr(0, eq));
        std::string val = trim(s.substr(eq + 1));
        auto it = g_values.find(key);
        if (it == g_values.end()) continue;
        char* end = nullptr;
        float v = std::strtof(val.c_str(), &end);
        if (end == val.c_str() || !std::isfinite(v)) continue;
        it->second.value = std::min(std::max(v, it->second.min), it->second.max);
    }
    std::fclose(f);
}

int save_file_locked() {
    if (g_path.empty()) return fail("config_save: chua co duong dan file (init voi path)");
    std::string tmp = g_path + ".tmp";
    FILE* f = std::fopen(tmp.c_str(), "w");
    if (!f) return fail("config_save: khong mo duoc " + tmp);
    std::fprintf(f, "# %s v%s\n", kConfigName, kConfigVersion);
    for (size_t i = 0; i < kConfigDefaultCount; ++i) {   // thu tu theo FROM.xml
        const char* k = kConfigDefaults[i].name;
        std::fprintf(f, "%s=%.6g\n", k, g_values[k].value);
    }
    if (std::fclose(f) != 0) return fail("config_save: loi ghi file");
    if (std::rename(tmp.c_str(), g_path.c_str()) != 0)
        return fail("config_save: khong doi ten duoc file tam");
    return 0;
}

float value_of(const char* k) { return g_values[k].value; }

} // namespace

extern "C" {

CONFIG_API int config_init(const char* path) {
    std::lock_guard<std::mutex> lk(g_mutex);
    load_defaults();
    g_path = path ? path : "";
    if (!g_path.empty()) load_file(g_path);
    g_ready = true;
    return 0;
}

CONFIG_API void config_shutdown(void) {
    std::lock_guard<std::mutex> lk(g_mutex);
    g_values.clear();
    g_path.clear();
    g_ready = false;
}

CONFIG_API int config_get_float(const char* key, float* out_value) {
    if (!key || !out_value) return fail("config_get_float: tham so NULL");
    std::lock_guard<std::mutex> lk(g_mutex);
    if (!g_ready) return fail("config chua init");
    auto it = g_values.find(key);
    if (it == g_values.end()) return fail(std::string("khong co key: ") + key);
    *out_value = it->second.value;
    return 0;
}

CONFIG_API int config_set_float(const char* key, float value) {
    if (!key) return fail("config_set_float: key NULL");
    if (!std::isfinite(value)) return fail("config_set_float: gia tri khong hop le (NaN/Inf)");
    std::lock_guard<std::mutex> lk(g_mutex);
    if (!g_ready) return fail("config chua init");
    auto it = g_values.find(key);
    if (it == g_values.end()) return fail(std::string("khong co key: ") + key);
    it->second.value = std::min(std::max(value, it->second.min), it->second.max);
    return 0;
}

CONFIG_API int config_reset(void) {
    std::lock_guard<std::mutex> lk(g_mutex);
    if (!g_ready) return fail("config chua init");
    for (auto& kv : g_values) kv.second.value = kv.second.def;
    return 0;
}

CONFIG_API int config_save(void) {
    std::lock_guard<std::mutex> lk(g_mutex);
    if (!g_ready) return fail("config chua init");
    return save_file_locked();
}

// Dead zone (co rescale) -> nhan sensitivity -> gioi han gia toc -> lam muot.
CONFIG_API float config_apply_filter(float input, float previous, float dt) {
    std::lock_guard<std::mutex> lk(g_mutex);
    if (!g_ready || !(dt > 0.0f) || !std::isfinite(input)) return previous;

    const float sens   = value_of("sensitivity");
    const float smooth = value_of("smooth");
    const float vmax   = value_of("maxSpeed");
    const float dz     = value_of("deadZone");

    float mag = std::fabs(input);
    float x = 0.0f;
    if (mag > dz) {
        float scaled = (mag - dz) / (1.0f - dz);
        x = std::copysign(scaled, input);
    }
    x *= sens;

    float target   = std::min(std::max(x, -1.0f), 1.0f) * vmax;
    float maxDelta = vmax * dt * 4.0f;
    float delta    = std::min(std::max(target - previous, -maxDelta), maxDelta);
    float limited  = previous + delta;

    return previous + (limited - previous) * (1.0f - smooth);
}

CONFIG_API const char* config_last_error(void) { return t_error.c_str(); }

} // extern "C"
