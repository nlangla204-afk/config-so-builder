#pragma once
/* API C thuan: dung duoc tu C, C++, JNI, dlopen... */
#ifdef __cplusplus
extern "C" {
#endif

#define CONFIG_API __attribute__((visibility("default")))

/* path: file luu config (dang key=value). NULL = chi dung gia tri mac dinh.
 * Neu file ton tai thi nap gia tri (tu kep min/max). Tra ve 0 = OK. */
CONFIG_API int   config_init(const char* path);
CONFIG_API void  config_shutdown(void);

/* Doc/ghi. Tra ve 0 = OK, <0 = loi (xem config_last_error). */
CONFIG_API int   config_get_float(const char* key, float* out_value);
CONFIG_API int   config_set_float(const char* key, float value);   /* tu kep [min,max] */
CONFIG_API int   config_reset(void);                               /* ve mac dinh */
CONFIG_API int   config_save(void);                                /* ghi ra file da init */

/* Bo loc dau vao tong quat (joystick/slider...), dung sensitivity, smooth,
 * maxSpeed, deadZone hien tai. input trong [-1,1], dt (giay) > 0,
 * previous = gia tri tra ve o lan goi truoc (khoi dau = 0). */
CONFIG_API float config_apply_filter(float input, float previous, float dt);

CONFIG_API const char* config_last_error(void);
CONFIG_API const char* config_build_info(void);

#ifdef __cplusplus
}
#endif
