==========================================================================
 CONFIG SO BUILDER
 FROM.xml + Source/ (C/C++)  ->  output/libconfig.so  (native shared library)
==========================================================================

1. CAU TRUC
-----------
Config_SO_Builder/
  FROM_Premium/FROM.xml    Container/metadata: Target, Modules, Values, Exports
  Source/                  Ma nguon C/C++ (*.c, *.cc, *.cpp) + header
    config_api.h             API C thuan (config_init/get/set/...)
    config_runtime.cpp       Runtime that: kho gia tri, nap/ghi file, bo loc
    config_buildinfo.c       Module C (chung minh .c cung duoc build)
    config_defaults.h        Khai bao bang mac dinh (du lieu sinh tu FROM.xml)
  test/test_config.cpp     Test link vao libconfig.so that
  output/                  Noi build.sh dat libconfig.so
  build.sh                 Builder
  manifest.json            Mo ta project
  build/                   (tu tao khi build) file .o va ma sinh tu dong

2. BUILD TREN TERMUX / ANDROID
------------------------------
  pkg update && pkg install clang      # 1 lan, lay clang/clang++
  cd Config_SO_Builder
  bash build.sh                        # -> output/libconfig.so
  bash build.sh test                   # build + chay test
  bash build.sh clean                  # don dep

Tren Linux khac (khong co clang++):  CXX=g++ CC=gcc ./build.sh

Quy trinh:
  FROM.xml -> Validate -> Doc Source/ -> Sinh config_defaults.cpp
           -> Compile .c/.cc/.cpp (-fPIC -std=c++17) -> Link (-shared)
           -> Xac minh ELF + kiem tra du symbol Exports -> output/libconfig.so

Loi duoc bao ro (kem ma thoat khac 0):
  ENV      chua cai clang++ / compiler
  FROM     thieu FROM.xml, XML sai, thieu the, Value sai (min<=default<=max),
           Module tro toi file khong ton tai, trung ten...
  SOURCE   Source/ rong hoac khong co .c/.cc/.cpp
  COMPILE  file nguon loi (in ra thong bao cua compiler)
  LINK     loi link (thieu ham, symbol khong tim thay...)
  VERIFY   file khong phai ELF, hoac thieu symbol da khai bao trong <Exports>

3. FROM.xml
-----------
  <Target>   ten output (libconfig.so), chuan C++ (c++14/17/20), abi (ghi chu)
  <Modules>  moi <Module name= src=> tro toi 1 file trong Source/
  <Values>   moi <Value name type="float" default min max>. Build sinh ra bang
             mac dinh + gioi han; runtime dung de kep gia tri.
  <Exports>  cac ham C phai xuat hien trong .so. Thieu la build bao loi.
Quy uoc: MOI phan tu nam tren MOT dong (build.sh doc bang sed/grep, khong can
python). Doi gia tri mac dinh: sua FROM.xml roi build lai.

Muon them 1 Value moi: them dong <Value .../> vao FROM.xml, build lai, roi
dung config_get_float("ten", &v) / config_set_float("ten", v).

4. API RUNTIME (Source/config_api.h)
------------------------------------
  int   config_init(const char* path);   // path=NULL: chi dung mac dinh;
                                         // co path: nap file key=value neu co
  int   config_get_float(const char* key, float* out);
  int   config_set_float(const char* key, float value);  // tu kep [min,max]
  int   config_save(void);               // ghi ra file (ghi tam roi rename)
  int   config_reset(void);
  float config_apply_filter(float input, float previous, float dt);
  void  config_shutdown(void);
  const char* config_last_error(void);
  const char* config_build_info(void);

Tra ve 0 = OK, am = loi. Gia tri that su nam trong bo nho (co mutex, an toan
da luong), duoc nap/ghi vao file van ban key=value, vi du:
  sensitivity=2.5
  smooth=0.8
  maxSpeed=100
  deadZone=0.05
config_apply_filter la vi du bo loc dau vao tong quat (dead zone -> nhan
sensitivity -> gioi han toc do/gia toc -> lam muot) dung 4 gia tri tren.

Vi du dung tu C++:
  #include "config_api.h"
  config_init("/data/data/<app>/files/config.cfg");
  float s; config_get_float("sensitivity", &s);
  config_set_float("smooth", 0.7f);
  config_save();
Link:  clang++ main.cpp -Ioutput_headers -Loutput -lconfig
(hoac nap bang dlopen/System.loadLibrary trong app cua ban)

5. KHONG LAM GIA DINH DANG - DOC KY
-----------------------------------
* ".so" la native shared library: file ELF chua ma may (arm64, x86_64...) do
  trinh bien dich + linker tao ra. He dieu hanh nap no bang dlopen().
* KHONG THE bien XML / DAT / TXT thanh ".so" bang cach doi duoi file hoac noi
  them text. File do khong co header ELF, nap se loi ngay ("invalid ELF header").
* FROM.xml chi la metadata/container: cho Builder biet module nao, gia tri
  nao, ham nao can xuat. Ban than no khong chua ma thuc thi.
* Chi ma nguon C/C++ trong Source/ moi duoc compiler bien thanh ma native.
  build.sh kiem tra byte dau '\x7fELF' va dung nm de xac nhan cac symbol trong
  <Exports> co that trong .so.

Luu y kien truc: .so build tren Termux (aarch64) chay tren thiet bi cung kien
truc. Build bang g++ tren PC x86_64 se ra .so x86_64, khong nap duoc tren
dien thoai ARM. Muon cross-compile can Android NDK (aarch64-linux-android-clang++).

6. PHAM VI
----------
Builder nay la config engine tong quat. FROM.xml duoc thiet ke lai tu dau,
toi gian, khong co quyen he thong, khong package inject, khong hook. Khong
co chuc nang game/hook/injection/bypass nao trong project nay.
