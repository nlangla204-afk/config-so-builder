#!/usr/bin/env bash
# =====================================================================
#  Config SO Builder  -  FROM.xml + Source/  ->  output/libconfig.so
#  Chay tren Termux/Android (clang++) hoac bat ky Linux co clang++/g++.
#
#  Cach dung:
#     ./build.sh           build ra output/libconfig.so
#     ./build.sh test      build + chay bo test (test/test_config.cpp)
#     ./build.sh clean     xoa build/ va output/libconfig.so
#
#  Bien moi truong (tuy chon):
#     CXX=g++  CC=gcc     dung compiler khac clang++ (mac dinh: clang++)
# =====================================================================
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
FROM_FILE="$ROOT/FROM_Premium/FROM.xml"
SRC_DIR="$ROOT/Source"
OUT_DIR="$ROOT/output"
BUILD_DIR="$ROOT/build"
GEN_DIR="$BUILD_DIR/generated"
OBJ_DIR="$BUILD_DIR/obj"

CXX="${CXX:-clang++}"
CC="${CC:-}"

if [ -t 1 ]; then R=$'\e[31m'; G=$'\e[32m'; Y=$'\e[33m'; B=$'\e[36m'; N=$'\e[0m'; else R=; G=; Y=; B=; N=; fi
step() { printf '%s[%s]%s %s\n' "$B" "$1" "$N" "$2"; }
ok()   { printf '   %sOK%s %s\n' "$G" "$N" "$1"; }
warn() { printf '   %sCANH BAO%s %s\n' "$Y" "$N" "$1" >&2; }
die()  { printf '\n%sLOI [%s]%s %s\n' "$R" "$1" "$N" "$2" >&2; [ -n "${3:-}" ] && printf '%s\n' "$3" >&2; exit "${4:-1}"; }

# ---------------------------------------------------------------- clean
if [ "${1:-}" = "clean" ]; then
    rm -rf "$BUILD_DIR" "$OUT_DIR/libconfig.so"
    echo "Da xoa build/ va output/libconfig.so"
    exit 0
fi

# attr "<dong xml>" ten  -> gia tri thuoc tinh
attr() { printf '%s' "$1" | sed -n "s/.*[[:space:]]$2=\"\([^\"]*\)\".*/\1/p"; }
# so thuc hop le?
is_num() { printf '%s' "$1" | grep -Eq '^-?[0-9]+(\.[0-9]+)?$'; }
# ra literal float C: 1 -> 1.0f, 0.5 -> 0.5f
flit() { case "$1" in *.*) printf '%sf' "$1";; *) printf '%s.0f' "$1";; esac; }

# ------------------------------------------------ 1. Kiem tra moi truong
step 1/6 "Kiem tra moi truong"
command -v "$CXX" >/dev/null 2>&1 || die ENV "Khong tim thay compiler '$CXX'." \
"Cai tren Termux:   pkg update && pkg install clang
(hoac dung compiler khac:  CXX=g++ CC=gcc ./build.sh)" 2
if [ -n "$CC" ]; then
    command -v "$CC" >/dev/null 2>&1 || die ENV "Khong tim thay compiler C '$CC'." "" 2
    C_CMD=("$CC")
else
    C_CMD=("$CXX" -x c)        # clang++ -x c: bien dich .c bang front-end C
fi
ok "compiler: $("$CXX" --version 2>&1 | head -n1)"

# ------------------------------------------------------- 2. Validate FROM
step 2/6 "Doc va kiem tra FROM.xml"
[ -f "$FROM_FILE" ] || die FROM "Thieu file: FROM_Premium/FROM.xml" "" 3
[ -s "$FROM_FILE" ] || die FROM "FROM.xml rong." "" 3

if command -v xmllint >/dev/null 2>&1; then
    XERR="$(xmllint --noout "$FROM_FILE" 2>&1)" || die FROM "FROM.xml khong phai XML hop le:" "$XERR" 3
fi

ROOT_LINE="$(grep -E '^[[:space:]]*<FROM[[:space:]]' "$FROM_FILE" | head -n1)"
[ -n "$ROOT_LINE" ] || die FROM "Thieu the goc <FROM name=\"...\" version=\"...\">" "" 3
FROM_NAME="$(attr "$ROOT_LINE" name)"; FROM_VER="$(attr "$ROOT_LINE" version)"
[ -n "$FROM_NAME" ] && [ -n "$FROM_VER" ] || die FROM "<FROM> phai co name va version." "" 3
printf '%s' "$FROM_NAME" | grep -Eq '^[A-Za-z0-9_.-]+$' || die FROM "name '$FROM_NAME' co ky tu khong hop le." "" 3
printf '%s' "$FROM_VER"  | grep -Eq '^[0-9A-Za-z_.-]+$' || die FROM "version '$FROM_VER' khong hop le." "" 3

for tag in Target Modules Values Exports; do
    grep -Eq "<$tag[ />]" "$FROM_FILE" || die FROM "Thieu the <$tag> trong FROM.xml" "" 3
done

# Target
TARGET_LINE="$(grep -E '^[[:space:]]*<Target[[:space:]]' "$FROM_FILE" | head -n1)"
T_OUT="$(attr "$TARGET_LINE" output)"; T_STD="$(attr "$TARGET_LINE" std)"; T_ABI="$(attr "$TARGET_LINE" abi)"
[ -n "$T_OUT" ] || T_OUT="libconfig.so"
[ "$T_OUT" = "libconfig.so" ] || die FROM "Target output phai la libconfig.so (hien tai: '$T_OUT')." "" 3
[ -n "$T_STD" ] || T_STD="c++17"
case "$T_STD" in c++14|c++17|c++20) ;; *) die FROM "Target std '$T_STD' khong ho tro (c++14|c++17|c++20)." "" 3;; esac

# Modules
MOD_SRCS=(); MOD_NAMES=()
while IFS= read -r line; do
    n="$(attr "$line" name)"; s="$(attr "$line" src)"
    [ -n "$n" ] && [ -n "$s" ] || die FROM "Module thieu name/src: $line" "" 3
    case "$s" in *..*|/*) die FROM "Module '$n': src khong duoc chua '..' hay duong dan tuyet doi." "" 3;; esac
    MOD_SRCS+=("$s"); MOD_NAMES+=("$n")
done < <(grep -E '^[[:space:]]*<Module[[:space:]]' "$FROM_FILE")
[ "${#MOD_SRCS[@]}" -gt 0 ] || die FROM "<Modules> khong co <Module ... /> nao." "" 3

# Values
VAL_NAMES=(); GEN_ROWS=""
while IFS= read -r line; do
    n="$(attr "$line" name)"; t="$(attr "$line" type)"
    d="$(attr "$line" default)"; lo="$(attr "$line" min)"; hi="$(attr "$line" max)"
    printf '%s' "$n" | grep -Eq '^[A-Za-z_][A-Za-z0-9_]*$' || die FROM "Value name '$n' khong hop le." "" 3
    [ "$t" = "float" ] || die FROM "Value '$n': type phai la float (hien tai '$t')." "" 3
    for v in "$d" "$lo" "$hi"; do is_num "$v" || die FROM "Value '$n': default/min/max phai la so (gap '$v')." "" 3; done
    awk -v d="$d" -v lo="$lo" -v hi="$hi" 'BEGIN{exit !(lo<=hi && d>=lo && d<=hi)}' \
        || die FROM "Value '$n': phai thoa min <= default <= max ($lo <= $d <= $hi)." "" 3
    for e in "${VAL_NAMES[@]:-}"; do [ "$e" = "$n" ] && die FROM "Value '$n' bi khai bao trung." "" 3; done
    VAL_NAMES+=("$n")
    GEN_ROWS+="    {\"$n\", $(flit "$d"), $(flit "$lo"), $(flit "$hi")},"$'\n'
done < <(grep -E '^[[:space:]]*<Value[[:space:]]' "$FROM_FILE")
[ "${#VAL_NAMES[@]}" -gt 0 ] || die FROM "<Values> khong co <Value ... /> nao." "" 3

# Exports
EXPORTS=()
while IFS= read -r line; do
    s="$(attr "$line" symbol)"
    printf '%s' "$s" | grep -Eq '^[A-Za-z_][A-Za-z0-9_]*$' || die FROM "Export symbol '$s' khong hop le." "" 3
    EXPORTS+=("$s")
done < <(grep -E '^[[:space:]]*<Export[[:space:]]' "$FROM_FILE")
[ "${#EXPORTS[@]}" -gt 0 ] || die FROM "<Exports> khong co <Export ... /> nao." "" 3

ok "FROM '$FROM_NAME' v$FROM_VER | ${#MOD_SRCS[@]} module | ${#VAL_NAMES[@]} value | ${#EXPORTS[@]} export | std=$T_STD"

# ---------------------------------------------------------- 3. Doc Source
step 3/6 "Doc Source/"
[ -d "$SRC_DIR" ] || die SOURCE "Thieu thu muc Source/" "" 4
SOURCES=()
while IFS= read -r -d '' f; do SOURCES+=("$f"); done < <(find "$SRC_DIR" -type f \( -name '*.c' -o -name '*.cc' -o -name '*.cpp' \) -print0 | sort -z)
[ "${#SOURCES[@]}" -gt 0 ] || die SOURCE "Source/ rong: khong co file .c / .cc / .cpp nao." "" 4

for k in "${!MOD_SRCS[@]}"; do
    [ -f "$SRC_DIR/${MOD_SRCS[$k]}" ] || die FROM "Module '${MOD_NAMES[$k]}' tro toi file khong ton tai: Source/${MOD_SRCS[$k]}" "" 3
done
for f in "${SOURCES[@]}"; do
    rel="${f#$SRC_DIR/}"; found=0
    for s in "${MOD_SRCS[@]}"; do [ "$s" = "$rel" ] && found=1; done
    [ "$found" = 1 ] || warn "Source/$rel khong duoc khai bao trong <Modules> (van duoc bien dich)."
done
ok "${#SOURCES[@]} file nguon"

# ------------------------------------------------- 4. Sinh ma tu FROM.xml
step 4/6 "Sinh build/generated/config_defaults.cpp tu FROM.xml"
rm -rf "$BUILD_DIR"; mkdir -p "$GEN_DIR" "$OBJ_DIR" "$OUT_DIR" || die IO "Khong tao duoc thu muc build/output." "" 5
{
    echo '// FILE SINH TU DONG boi build.sh tu FROM.xml - KHONG SUA TAY'
    echo '#include "config_defaults.h"'
    echo "const ConfigDefault kConfigDefaults[] = {"
    printf '%s' "$GEN_ROWS"
    echo "};"
    echo "const size_t kConfigDefaultCount = ${#VAL_NAMES[@]};"
    echo "const char* const kConfigName = \"$FROM_NAME\";"
    echo "const char* const kConfigVersion = \"$FROM_VER\";"
} > "$GEN_DIR/config_defaults.cpp" || die IO "Khong ghi duoc file sinh ra." "" 5
ok "$(( ${#VAL_NAMES[@]} )) gia tri mac dinh"

# --------------------------------------------------------- 5. Bien dich
step 5/6 "Bien dich"
STAMP="$(date -u +%Y-%m-%dT%H:%M:%SZ)"
COMMON=(-fPIC -O2 -Wall -Wextra -fvisibility=hidden -I"$SRC_DIR" "-DCONFIG_BUILD_STAMP=\"$STAMP\"")
OBJS=(); i=0; FAILED=0

compile_one() {  # $1=file nguon  $2=lenh...  ; dat ten .o theo chi so
    local f="$1"; shift
    local obj="$OBJ_DIR/$(printf '%03d' "$i")_$(basename "$f").o"
    local log
    if log="$("$@" -c "$f" -o "$obj" 2>&1)"; then
        ok "${f#$ROOT/}"
        [ -n "$log" ] && printf '%s\n' "$log" | sed 's/^/      /' >&2
        OBJS+=("$obj")
    else
        printf '   %sLOI BIEN DICH%s %s\n%s\n' "$R" "$N" "${f#$ROOT/}" "$log" | sed 's/^/      /' >&2
        FAILED=$((FAILED+1))
    fi
    i=$((i+1))
}

for f in "${SOURCES[@]}" "$GEN_DIR/config_defaults.cpp"; do
    case "$f" in
        *.c)          compile_one "$f" "${C_CMD[@]}" -std=c11 "${COMMON[@]}" ;;
        *.cc|*.cpp)   compile_one "$f" "$CXX" -std="$T_STD" "${COMMON[@]}" ;;
    esac
done
[ "$FAILED" -eq 0 ] || die COMPILE "$FAILED file bien dich that bai (xem loi phia tren)." "" 6

# --------------------------------------------------------------- 6. Link
step 6/6 "Link shared library"
OUT_SO="$OUT_DIR/libconfig.so"
rm -f "$OUT_SO"
LOG="$("$CXX" -shared -fPIC -std="$T_STD" -Wl,--no-undefined -Wl,-soname,libconfig.so \
        "${OBJS[@]}" -o "$OUT_SO" 2>&1)" || die LINK "Link that bai:" "$LOG" 7
[ -s "$OUT_SO" ] || die LINK "Link bao thanh cong nhung output/libconfig.so khong ton tai/rong." "" 7

# --- Xac minh day la ELF shared object that, va du Exports
[ "$(head -c4 "$OUT_SO" | od -An -c | tr -d ' ')" = '177ELF' ] || die VERIFY "libconfig.so khong phai file ELF!" "" 8
if command -v file >/dev/null 2>&1; then ok "$(file -b "$OUT_SO" | cut -c1-110)"; fi
NM=""; for c in llvm-nm nm; do command -v "$c" >/dev/null 2>&1 && { NM="$c"; break; }; done
if [ -n "$NM" ]; then
    SYMS="$("$NM" -D --defined-only "$OUT_SO" 2>/dev/null | awk '{print $NF}')"
    MISSING=""
    for s in "${EXPORTS[@]}"; do printf '%s\n' "$SYMS" | grep -qx "$s" || MISSING+=" $s"; done
    [ -z "$MISSING" ] || die VERIFY "FROM.xml khai bao Export nhung .so khong co symbol:" "$MISSING" 8
    ok "du ${#EXPORTS[@]}/${#EXPORTS[@]} symbol export"
else
    warn "khong co nm/llvm-nm: bo qua buoc kiem tra symbol export."
fi
printf '\n%sTHANH CONG%s -> %s (%s bytes)\n' "$G" "$N" "output/libconfig.so" "$(wc -c < "$OUT_SO" | tr -d ' ')"

# ---------------------------------------------------------------- test
if [ "${1:-}" = "test" ]; then
    step TEST "Bien dich va chay test/test_config.cpp"
    [ -f "$ROOT/test/test_config.cpp" ] || die TEST "Thieu test/test_config.cpp" "" 9
    "$CXX" -std="$T_STD" -I"$SRC_DIR" "$ROOT/test/test_config.cpp" -L"$OUT_DIR" -lconfig \
        -Wl,-rpath,"$OUT_DIR" -o "$BUILD_DIR/test_config" 2>&1 || die TEST "Bien dich test that bai." "" 9
    "$BUILD_DIR/test_config" || die TEST "Test that bai." "" 9
fi
exit 0
